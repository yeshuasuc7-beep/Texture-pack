--------------------------------------------------------------------

       ___  ___ _      __
      / _ \/ _ \ | /| / /
     / , _/ ___/ |/ |/ / 
    /_/|_/_/   |__/|__/  

 This ResourcePack was composed using the ResourcePack Workbench.

 Please, keep this file to give a credit to it's author, MightyPork.

--------------------------------------------------------------------

 * MightyPork on twitter    -> @MightyPork

 * RPW on Planet Minecraft  -> http://goo.gl/BwlCs

 * RPW on Minecraft Forum   -> http://goo.gl/ipbcH

 * RPW on GitHub            -> https://github.com/MightyPork/rpw
	 
--------------------------------------------------------------------
